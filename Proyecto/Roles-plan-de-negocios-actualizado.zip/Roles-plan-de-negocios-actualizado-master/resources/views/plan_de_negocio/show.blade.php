<x-app-layout class="flex flex-nowrap">
    
    <x-sidebar :plan_de_negocio="$plan_de_negocio"></x-sidebar>
    <div class="mx-auto">
        <h1 class="text-gray-100 py-6 text-2xl">Información de la empresa</h1>
    </div>

</x-app-layout>